/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */
import React from 'react';
const Footer = () => {
    return (
        <footer>
            <p>&copy; 2024 Max's Handyman Services. All Rights Reserved.</p>
        </footer>
    );
};

export default Footer;


